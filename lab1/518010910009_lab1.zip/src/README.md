# READEME

## 介绍

分别使用 Logistic Regression, Support Vector Machine, Multi-layer Perceptron 三种方法对数据集进行二分类任务，比较三种方法的性能。

## 使用

分别运行 .py 文件即可。默认数据集路径为 "../lab1_dataset/***data***.csv"

## 说明

- Logistic Regression, Support Vector Machine 可以使用迭代次数（默认）或者收敛条件作为停止条件。
- 在计算运行时间时未统计训练过程中对结果的测试时间。